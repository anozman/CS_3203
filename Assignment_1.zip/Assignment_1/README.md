# README
## Assignment 1 
This is the RESTful API that was required of us to make using an imported JSON file

## Start Up
First and foremost, one must have Node.js installed on their machine in order to run the following program

The program currently hosts three active files, express.js, index.html, and favs.json

When ready to run the program, go into the directory with the previous files and use the following command:
```bash
node express.js
```

## express.js
This file is the backend of this API. Here is where the code is implemented for the server, the API, and handles the connenction to the front end 
## index.html
This is the front end of the program. On the webpage there are forms that when submitted make the proper API request
## favs.json
This file is the initial starting point of the tweets that are going to be manipulated

## About
The program will run on a local server on port 3000
The program brings in the favs.json set of tweets into a local array, where things are then manipulated

### Notes
The Front end is not wired correctly to the back end, and thus null values are passed through
I could not get the "PUT" and "DELETE" calls to come through correctly without implementing them under "GET"
--All functions work on individual calls, but not with the front end

